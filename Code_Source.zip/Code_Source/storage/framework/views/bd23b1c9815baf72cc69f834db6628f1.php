<!DOCTYPE html>
<html lang="fr">

<head>
    <!--  Header -->
    <div class="container-fluid p-0">
        <img src="<?php echo e(url('img/voiture1.jpg')); ?>" style="width: 100%;">
    </div>
    <!-- End Header -->

    <!-- Bootstrap CSS & JS -->
    <link rel="stylesheet" href="<?php echo e(url('css/bootstrap.min.css')); ?>">
    <script src="<?php echo e(url('js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- END Bootstrap -->

    <!-- additional  CSS  -->
    <link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">
    <!-- END additional CSS -->

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parc-Voiture|Listing</title>
</head>

<body>

    <div class="container">
        <a href="<?php echo e(route('cars.index')); ?>">Toutes les voitures</a>
        <h1>VOITURES A LA UNE</h1>
        <div class="row">
            <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col">
                <?php echo $__env->make('vueVoitures.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>


</body>

</html><?php /**PATH X:\Documents\Programmation\Laravel\TP_Parc\resources\views/home.blade.php ENDPATH**/ ?>