

<?php $__env->startSection('content'); ?>


<table class="table table-striped">
    <thead>
        <tr>
            <th>Nom</th>
            <th>Email</th>
            <th>Marque_Voiture</th>
            <th>Modele_Voiture</th>
            <th>Prix</th>
            <th>Date_Debut_Emprunt</th>
            <th>Date_Fin_Emprunt</th>
            <th>Date_Restitution</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $operations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($operation->nom_cli); ?></td>
            <td><?php echo e($operation->email_cli); ?></td>
            <td><?php echo e($operation->marque_voiture); ?></td>
            <td><?php echo e($operation->modele_voiture); ?></td>
            <td><?php echo e(number_format($operation->prix, 0, ',', ' ')); ?></td>
            <td><?php echo e($operation->date_debut_emprunt); ?></td>
            <td><?php echo e($operation->date_fin_emprunt); ?></td>
            <td><?php echo e($operation->date_restitution); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\Documents\Programmation\Laravel\TP_Parc\resources\views/operation/listoperation.blade.php ENDPATH**/ ?>