


<?php $__env->startSection('content'); ?>


<div class="mt-4">
    <h4>Intéressé par cette voiture ?</h4>
    <h5>Si oui, renseigner les informations ci-dessous</h5>

    <form action="" method="post" class="vstack gap-4">
        <?php echo csrf_field(); ?>
        <div class="row">
            <?php echo $__env->make('shared.input',['class' => 'col','name' => 'firstname', 'label' => 'Prénom'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('shared.input',['class' => 'col','name' => 'lastname', 'label' => 'Nom'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
        <div class="row">
            <?php echo $__env->make('shared.input',['class' => 'col','name' => 'phone', 'label' => 'Téléphone'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make('shared.input',['type'=> 'email','class' => 'col','name' => 'email', 'label' => 'Email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php echo $__env->make('shared.input',['type'=> 'text-area','class' => 'col','name' => 'message', 'label' => 'Votre message'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </form>
</div>
<h1></h1>
<h2></h2>

<div class="row">
    <a href="<?php echo e(route('formPayMob')); ?>" class="btn btn-primary">Paiement par Mobile Money</button>
</div>

<div class="row">
    <a href="<?php echo e(route('formPayBank')); ?>" class="btn btn-primary">Paiement par carte bancaire</button>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\Documents\Programmation\Laravel\TP_Parc\resources\views/vueVoitures/show.blade.php ENDPATH**/ ?>