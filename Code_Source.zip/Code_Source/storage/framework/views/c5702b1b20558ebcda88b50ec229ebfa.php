


<?php $__env->startSection('content'); ?>

<div class="mt-4">

    <form action="" method="post">
        <?php echo csrf_field(); ?>
        <label for="num">Numéro de téléphone de la transaction</label>
        <input type="text" name="num" required>
        <button type="submit">Soumettre</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\Documents\Programmation\Laravel\TP_Parc\resources\views/operation/formPayMob.blade.php ENDPATH**/ ?>