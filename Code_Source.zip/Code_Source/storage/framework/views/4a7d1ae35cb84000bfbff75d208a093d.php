

<?php $__env->startSection('marque',$property->exists ? 'Editer un bien':'Créer une voiture'); ?>

<?php $__env->startSection('content'); ?>

<h1><?php echo $__env->yieldContent('marque'); ?></h1>

<form class="vstack gap-2" action="<?php echo e(route($property->exists ? 'admin.property.update' : 'admin.property.store', $property)); ?>" method="post">

    <?php echo csrf_field(); ?>
    <?php echo method_field($property->exists ? 'put' : 'post'); ?>

    <div class="row">
        <?php echo $__env->make('admin\cars\shared', ['class' => 'col','label'=>'Marque','name'=>'marque','value'=>$property->marque], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col row">
            <?php echo $__env->make('admin\cars\shared', ['class' => 'col','name'=>'modele','value'=>$property->modele], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="col row">
        <?php echo $__env->make('admin\cars\shared', ['class' => 'col','name'=>'année de fabrication','value'=>$property->annee_fabrication], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin\cars\shared', ['class' => 'col','name'=>'capacite de passagers','value'=>$property->capacite_passagers], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div>
        <button class="btn btn-primary">
            <?php if($property->exists): ?>
            Modifier
            <?php else: ?>
            Créer
            <?php endif; ?>
        </button>
    </div>

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\Documents\Programmation\Laravel\TP_Parc\resources\views/admin/cars/form.blade.php ENDPATH**/ ?>