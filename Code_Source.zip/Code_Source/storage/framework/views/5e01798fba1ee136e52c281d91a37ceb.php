


<?php $__env->startSection('content'); ?>

<div class="mt-4">

    <form action="" method="post">
        <?php echo csrf_field(); ?>
        <label for="carte">Numéro de compte</label>
        <input type="text" name="carte" required>
        <button type="submit">Soumettre</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\Documents\Programmation\Laravel\TP_Parc\resources\views/operation/formPayBank.blade.php ENDPATH**/ ?>