<!DOCTYPE html>
<html lang="fr">

<head>


    <!-- Bootstrap CSS & JS -->
    <link rel="stylesheet" href="<?php echo e(url('css/bootstrap.min.css')); ?>">
    <script src="<?php echo e(url('js/bootstrap.bundle.min.js')); ?>"></script>
    <!-- END Bootstrap -->

    <!-- additional  CSS  -->
    <link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">
    <!-- END additional CSS -->

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parc-Voiture|Administration</title>
</head>

<body>

    <button type="button" class="btn btn-primary">Mon Bouton Bootstrap</button>


</body>

</html><?php /**PATH X:\Documents\Programmation\Laravel\TP_Parc\resources\views/layout.blade.php ENDPATH**/ ?>