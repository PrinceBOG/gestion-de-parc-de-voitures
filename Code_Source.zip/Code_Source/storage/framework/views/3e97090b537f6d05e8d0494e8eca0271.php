

<?php $__env->startSection('marque','Nos voitures'); ?>

<?php $__env->startSection('content'); ?>

<h1></h1>
<a href="<?php echo e(route('login')); ?>" class="btn btn-primary" method="post">Se connecter en tant qu'administrateur</a>

<div class="bg-light p-5 mb-5 text-center">
    <form action="" method="get" class="container d-flex gap-2">
        <input type="number" placeholder="Budget max" class="form-control" name="price" value="<?php echo e($input['prix'] ?? ''); ?>">
    </form>
</div>

<div class="container">
    <div class="row">
        <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-3 mb-4">
            <?php echo $__env->make('vueVoitures.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<div class="my-4">
    <?php echo e($properties->links()); ?>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\Documents\Programmation\Laravel\TP_Parc\resources\views/vueVoitures/index.blade.php ENDPATH**/ ?>