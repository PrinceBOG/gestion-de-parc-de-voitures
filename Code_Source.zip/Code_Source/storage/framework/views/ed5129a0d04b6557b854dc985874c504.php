<div class="card">
    <div class="card-body">
        <h5 class="card-title">
            <a href="<?php echo e(route('loginCli')); ?>"><?php echo e($property->marque); ?></a>
        </h5>
        <img src="<?php echo e($property->image_path); ?>" alt="<?php echo e($property->image_url); ?>" style="width: 100% ">
        <p class="card-text">
            <?php echo e($property->modele); ?> - <?php echo e($property->annee_fabrication); ?>

        </p>
        <div class="text-primary" style="font-size: 1.6rem; font-weight:bold;">
            <?php echo e(number_format($property->prix, thousands_separator: ' ')); ?>

        </div>
    </div>
</div><?php /**PATH X:\Documents\Programmation\Laravel\TP_Parc\resources\views/vueVoitures/card.blade.php ENDPATH**/ ?>