

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center">
    <h1>Toutes les voitures</h1>
    <a href="<?php echo e(route('logout')); ?>" class="btn btn-primary" method="delete">Se déconnecter</a>
</div>

<a href="<?php echo e(route('admin.property.create')); ?>" class="btn btn-primary">Ajouter une voiture</a>
<a href="<?php echo e(route('admin.property.editform')); ?>" class="btn btn-secondary">Modifier une voiture</a>

<table class="table table-striped">
    <thead>
        <tr>
            <th>Matricule de la voiture</th>
            <th>Marque</th>
            <th>Modèle</th>
            <th>Année de fabrication</th>
            <th>Transmission</th>
            <th>Prix</th>
            <th>Disponible</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($property->id); ?></td>
            <td><?php echo e($property->marque); ?></td>
            <td><?php echo e($property->modele); ?></td>
            <td><?php echo e($property->annee_fabrication); ?></td>
            <td><?php echo e($property->transmission); ?></td>
            <td><?php echo e(number_format($property->prix, 0, ',', ' ')); ?></td>
            <td><?php echo e($property->disponible); ?></td>
            <td>
                <div class="d-flex gap-2 w-100 justify-content-end">
                    <a href="<?php echo e(route('admin.property.editform',$property)); ?>" class="btn btn-secondary">Editer</a>
                    <form action="<?php echo e(route('admin.property.destroy',$property)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-danger">Supprimer</button>
                    </form>
                </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($properties->links()); ?>


<a href="<?php echo e(route('operation.index')); ?>">Voir toutes les opérations d'emprunt</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\Documents\Programmation\Laravel\TP_Parc\resources\views/admin/properties/index.blade.php ENDPATH**/ ?>