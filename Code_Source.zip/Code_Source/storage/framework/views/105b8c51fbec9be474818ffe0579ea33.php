

<?php $__env->startSection('title', 'Se connecter'); ?>

<?php $__env->startSection('content'); ?>

<div class="mt-4 container">
    <h1><?php echo $__env->yieldContent('title'); ?></h1>


    <form method="post" action="<?php echo e(route('loginCli')); ?>" class="v-stack gap-3">
        <?php echo csrf_field(); ?>
        <?php echo $__env->make('shared.input',['type'=> 'email', 'class' => 'col', 'name' => 'email', 'label'=>'Email'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('shared.input',['type'=> 'password', 'class' => 'col', 'name' => 'password', 'label'=>'Mot de passe'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="text-center" style="margin-top: 20px;">
            <button class="btn btn-primary">Se connecter</button>
        </div>

        <a href="<?php echo e(route('inscrire')); ?>">Créer un compte</a>




    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\Documents\Programmation\Laravel\TP_Parc\resources\views/auth/loginCli.blade.php ENDPATH**/ ?>