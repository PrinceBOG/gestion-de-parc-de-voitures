

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center" , <h1>Toutes les voitures</h1>
    <a href="<?php echo e(route('admin.property.create')); ?>" class="btn btn-primary">Ajouter une voiture</a>
</div>

<table class="table table-striped" , <thead>
    <tr>
        <th>Marque</th>
        <th>Modèle</th>
        <th>Transmission</th>
        <th>Prix</th>
    </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $property): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td-><?php echo e($property->marque); ?>></td>
                <td-><?php echo e($property->modele); ?>></td>
                    <td-><?php echo e(number_format($property->price,thousands_separator: ' ')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($properties->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH X:\Documents\Programmation\Laravel\TP_Parc\resources\views/admin/properties.blade.php ENDPATH**/ ?>