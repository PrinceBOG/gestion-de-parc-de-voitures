<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Property extends Model
{
    use HasFactory;

    protected $table = 'properties';

    protected $fillable = [
        'id',
        'marque',
        'modele',
        'annee_fabrication',
        'capacite_passagers',
        'transmission',
        'image_url',
        'image_path',
        'prix',
        'disponible',
    ];

    public function getSlug(): string
    {
        return Str::slug($this->marque);
    }
}
