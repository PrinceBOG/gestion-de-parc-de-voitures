<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Operation extends Model
{
    use HasFactory;

    protected $table = 'operations';

    protected $fillable = [
        'nom_cli',
        'email_cli',
        'Prix',
        'marque_voiture',
        'modele_voiture',
        'date_debut_emprunt',
        'date_fin_emprunt',
        'date_restitution',
    ];
}
