<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GalleryController extends Controller
{
    public function showUploadForm()
    {
        return view('gallery.upload');
    }

    public function upload(Request $request)
    {
        $request->validate([
            'image' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
        ]);

        $imagePath = $request->file('image')->store('gallery', 'public');

        // Enregistrez le chemin de l'image dans la base de données ici...

        return redirect()->route('gallery.upload.form')->with('success', 'Image téléchargée avec succès.');
    }
}
