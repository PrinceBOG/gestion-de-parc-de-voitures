<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PaiementController extends Controller
{
    public function formPayBank()
    {
        return view('operation.formPayBank');
    }

    public function formPayMob()
    {
        return view('operation.formPayMob');
    }

    public function restitution()
    {
        return view('operation.restitution');
    }
}
