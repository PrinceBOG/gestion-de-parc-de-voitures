<?php

namespace App\Http\Controllers;

use App\Http\Requests\InscriptionRequest;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class InscriptionController extends Controller
{
    public function inscrire()
    {
        return view('auth.inscription');
    }

    public function valider(InscriptionRequest $request)
    {
        $credentials = $request->validated();
        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
            return redirect()->intended(route('admin.property.index'));
        }

        return back()->withErrors([
            'email' => 'Identificants incorrects'
        ])->onlyInput('email');
    }

    public function enregistrer(Request $request)
    {
        $name = $request->input('name');
        $email = $request->input('email');
        $password = $request->input('password');

        DB::statement("INSERT INTO users (name,email,password) VALUES(?,?,?)", [$name, $email, $password]);

        return redirect()->route('login');
    }
}
