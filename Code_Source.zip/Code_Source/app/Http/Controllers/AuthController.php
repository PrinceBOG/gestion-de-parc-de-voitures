<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginRequest;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Routing\Redirector;

class AuthController extends Controller
{
    public function login()
    {
        /*if (!User::where('email', 'johndoe@gmail.com')->exists()) {
            User::create([
                'name' => 'John',
                'email' => 'john@gmail.com',
                'password' => Hash::make('0000')
            ])
        }*/
        return view('auth.login');
    }

    public function dologin(LoginRequest $request)
    {
        $credentials = $request->validated();
        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
            return redirect()->intended(route('admin.property.index'));
        }

        return back()->withErrors([
            'email' => 'Identificants incorrects'
        ])->onlyInput('email');
    }

    public function logout()
    {
        Auth::logout();
        return to_route('login')->with('success', 'Vous êtes maintenant déconnecté');
    }

    public function loginCli()
    {
        /*if (!User::where('email', 'johndoe@gmail.com')->exists()) {
            User::create([
                'name' => 'John',
                'email' => 'john@gmail.com',
                'password' => Hash::make('0000')
            ])
        }*/
        return view('auth.loginCli');
    }

    public function dologinCli(LoginRequest $request)
    {
        $credentials = $request->validated();
        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
            return redirect()->intended(route('cars.show'));
        }

        return back()->withErrors([
            'email' => 'Identificants incorrects'
        ])->onlyInput('email');
    }

    public function loginRest()
    {
        /*if (!User::where('email', 'johndoe@gmail.com')->exists()) {
            User::create([
                'name' => 'John',
                'email' => 'john@gmail.com',
                'password' => Hash::make('0000')
            ])
        }*/
        return view('auth.loginRest');
    }

    public function dologinRest(LoginRequest $request)
    {
        $credentials = $request->validated();
        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
            return redirect()->intended(route('restitution'));
        }

        return back()->withErrors([
            'email' => 'Identificants incorrects'
        ])->onlyInput('email');
    }
}
