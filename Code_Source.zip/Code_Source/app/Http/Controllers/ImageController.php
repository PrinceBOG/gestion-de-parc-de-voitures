<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class ImageController extends Controller
{
    public function showImages()
    {
        $properties = DB::table('properties')->get();

        return view('home', ['properties' => $properties]);
    }
}
