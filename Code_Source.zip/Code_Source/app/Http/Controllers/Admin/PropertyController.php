<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\PropertyFormRequest;
use App\Models\Property;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;

class PropertyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\View\View
     */
    public function index()
    {
        //$properties = Property::paginate(25);
        return view('admin.properties.index', [
            'properties' => Property::orderBy('marque', 'asc')->paginate(25)
            //'properties' => $properties
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\View\View
     */
    public function create()
    {
        $property = new Property();

        return view('admin.properties.form', ['property' => $property]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  PropertyFormRequest  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $request->validate([
            'marque' => 'required',
            'modele' => 'required',
            'annee_fabrication' => 'required',
            'capacite_passagers' => 'required',
            'transmission' => 'required',
            'image_path' => 'required',
            'prix' => 'required',
            'disponible' => 'boolean',
        ]);

        $marque = $request->input('marque');
        $modele = $request->input('modele');
        $annee_fabrication = $request->input('annee_fabrication');
        $capacite = $request->input('capacite');
        $transmission = $request->input('transmission');
        $image_path = $request->input('image_path');
        $prix = $request->input('prix');
        $disponible = $request->input('disponible', 0);

        // Utilisation de la façade DB pour exécuter une requête SQL brute
        DB::statement("INSERT INTO properties (marque, modele, annee_fabrication,capacite_passagers,transmission,image_path,prix, disponible) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", [$marque, $modele, $annee_fabrication, $capacite, $transmission, $image_path, $prix, $disponible]);

        return redirect()->route('admin.property.index')->with('success', 'Voiture créée avec succès');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  string  $id
     * @return \Illuminate\View\View
     */
    public function edit(Request $request)
    {
        $request->validate([
            'matricule' => 'required',
            'marque' => 'required',
            'modele' => 'required',
            'annee_fabrication' => 'required',
            'capacite_passagers' => 'required',
            'transmission' => 'required',
            'image_path' => 'required',
            'prix' => 'required',
            'disponible' => 'boolean',
        ]);

        DB::update(
            "UPDATE properties 
            SET 
                marque = ?, 
                modele = ?, 
                annee_fabrication = ?, 
                capacite_passagers = ?, 
                transmission = ?, 
                image_path = ?, 
                prix = ?, 
                disponible = ?
            WHERE id = ?",
            [
                $request->input('marque'),
                $request->input('modele'),
                $request->input('annee_fabrication'),
                $request->input('capacite_passagers'),
                $request->input('transmission'),
                $request->input('image_path'),
                $request->input('prix'),
                $request->input('disponible', 0),
                $request->input('matricule'),
            ]
        );
        return redirect()->route('admin.property.index')->with('success', 'Voiture modifiée avec succès');
    }

    public function editform(Property $property)
    {
        return view('admin.properties.edit', ['property' => $property]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  PropertyFormRequest  $request
     * @param  string  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(PropertyFormRequest $request, Property $property)
    {
        $property->update($request->validated());
        return to_route('admin.property.index')->with('sucess', 'La voiture a été modifiée avec succès');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  string  $id
     * @return \Illuminate\Http\RedirectResponse
     */
    public function destroy(Property $property)
    {
        $property->delete();
        return to_route('admin.property.index')->with('sucess', 'La voiture a été supprimée avec succès');
    }

    /*public function justpage()
    {
        return true;
    }*/
}
