<?php

namespace App\Http\Controllers;

use App\Http\Requests\PropertyContactRequest;
use App\Models\Property;
use App\Http\Requests\SearchPropertiesRequest;
use Illuminate\Http\Request;

class CarsController extends Controller
{
    public function index(SearchPropertiesRequest $request)
    {
        $query = Property::query();
        if ($request->has('price')) {
            $query = $query->where('prix', '<=', $request->input('price'));
        };
        return view('vueVoitures.index', [
            'properties' => $query->paginate(15),
            'input' => $request->validated()
        ]);
    }

    public function show(Property $property)
    {
        return view('vueVoitures.show', [
            'property' => $property
        ]);
    }

    public function contact(Property $property, PropertyContactRequest $request)
    {
    }
}
