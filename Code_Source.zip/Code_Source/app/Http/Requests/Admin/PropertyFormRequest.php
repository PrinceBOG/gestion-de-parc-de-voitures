<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class PropertyFormRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'marque' => ['required', 'min:4'],
            'modele' => ['required', 'min:1'],
            'annee_fabrication' => ['required', 'min:4', 'max:4'],
            'capacite_passagers' => ['required', 'min:1', 'max:1'],
            'transmission' => ['required', 'min:6', 'max:11'],
            //'image_url' => ['required'],
            'prix' => ['required', 'min:6'],
            'disponible' => ['required', 'boolean']
        ];
    }
}
