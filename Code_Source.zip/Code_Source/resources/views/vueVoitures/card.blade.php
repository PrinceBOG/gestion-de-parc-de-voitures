<div class="card">
    <div class="card-body">
        <h5 class="card-title">
            <a href="{{route('loginCli')}}">{{$property->marque}}</a>
        </h5>
        <img src="{{ $property->image_path }}" alt="{{ $property->image_url }}" style="width: 100% ">
        <p class="card-text">
            {{ $property->modele}} - {{$property->annee_fabrication}}
        </p>
        <div class="text-primary" style="font-size: 1.6rem; font-weight:bold;">
            {{ number_format($property->prix, thousands_separator: ' ')}}
        </div>
    </div>
</div>