@extends('admin.admin')

@section('marque','Nos voitures')

@section('content')

<h1></h1>
<a href="{{ route('login') }}" class="btn btn-primary" method="post">Se connecter en tant qu'administrateur</a>

<div class="bg-light p-5 mb-5 text-center">
    <form action="" method="get" class="container d-flex gap-2">
        <input type="number" placeholder="Budget max" class="form-control" name="price" value="{{$input['prix'] ?? ''}}">
    </form>
</div>

<div class="container">
    <div class="row">
        @foreach($properties as $property)
        <div class="col-3 mb-4">
            @include('vueVoitures.card')
        </div>
        @endforeach
    </div>
</div>

<div class="my-4">
    {{$properties->links()}}
</div>

@endsection