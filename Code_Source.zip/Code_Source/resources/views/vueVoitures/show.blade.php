@extends('admin.admin')


@section('content')


<div class="mt-4">
    <h4>Intéressé par cette voiture ?</h4>
    <h5>Si oui, renseigner les informations ci-dessous</h5>

    <form action="" method="post" class="vstack gap-4">
        @csrf
        <div class="row">
            @include('shared.input',['class' => 'col','name' => 'firstname', 'label' => 'Prénom'])
            @include('shared.input',['class' => 'col','name' => 'lastname', 'label' => 'Nom'])

        </div>
        <div class="row">
            @include('shared.input',['class' => 'col','name' => 'phone', 'label' => 'Téléphone'])
            @include('shared.input',['type'=> 'email','class' => 'col','name' => 'email', 'label' => 'Email'])
        </div>
        @include('shared.input',['type'=> 'text-area','class' => 'col','name' => 'message', 'label' => 'Votre message'])
    </form>
</div>
<h1></h1>
<h2></h2>

<div class="row">
    <a href="{{route('formPayMob')}}" class="btn btn-primary">Paiement par Mobile Money</button>
</div>

<div class="row">
    <a href="{{route('formPayBank')}}" class="btn btn-primary">Paiement par carte bancaire</button>
</div>

@endsection