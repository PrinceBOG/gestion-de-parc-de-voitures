<!DOCTYPE html>
<html lang="fr">

<head>
    <!--  Header -->
    <div class="container-fluid p-0">
        <img src="{{ url('img/voiture1.jpg')}}" style="width: 100%;">
    </div>
    <!-- End Header -->

    <!-- Bootstrap CSS & JS -->
    <link rel="stylesheet" href="{{ url('css/bootstrap.min.css')}}">
    <script src="{{ url('js/bootstrap.bundle.min.js') }}"></script>
    <!-- END Bootstrap -->

    <!-- additional  CSS  -->
    <link rel="stylesheet" href="{{ url('css/style.css') }}">
    <!-- END additional CSS -->

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Parc-Voiture|Listing</title>
</head>

<body>

    <div class="container">
        <a href="{{ route('cars.index') }}">Toutes les voitures</a>
        <h1>VOITURES A LA UNE</h1>
        <div class="row">
            @foreach($properties as $property)
            <div class="col">
                @include('vueVoitures.card')
            </div>
            @endforeach
        </div>


</body>

</html>