@extends('admin.admin')

@section('title', 'Se connecter')

@section('content')

<div class="mt-4 container">
    <h1>@yield('title')</h1>


    <form method="post" action="{{route('loginCli')}}" class="v-stack gap-3">
        @csrf
        @include('shared.input',['type'=> 'email', 'class' => 'col', 'name' => 'email', 'label'=>'Email'])
        @include('shared.input',['type'=> 'password', 'class' => 'col', 'name' => 'password', 'label'=>'Mot de passe'])

        <div class="text-center" style="margin-top: 20px;">
            <button class="btn btn-primary">Se connecter</button>
        </div>

        <a href="{{route('inscrire')}}">Créer un compte</a>




    </form>
</div>

@endsection