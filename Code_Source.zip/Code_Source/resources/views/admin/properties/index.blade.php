@extends('admin.admin')

@section('content')
<div class="d-flex justify-content-between align-items-center">
    <h1>Toutes les voitures</h1>
    <a href="{{ route('logout') }}" class="btn btn-primary" method="delete">Se déconnecter</a>
</div>

<a href="{{ route('admin.property.create') }}" class="btn btn-primary">Ajouter une voiture</a>
<a href="{{ route('admin.property.editform')}}" class="btn btn-secondary">Modifier une voiture</a>

<table class="table table-striped">
    <thead>
        <tr>
            <th>Matricule de la voiture</th>
            <th>Marque</th>
            <th>Modèle</th>
            <th>Année de fabrication</th>
            <th>Transmission</th>
            <th>Prix</th>
            <th>Disponible</th>
        </tr>
    </thead>
    <tbody>
        @foreach($properties as $property)
        <tr>
            <td>{{ $property->id }}</td>
            <td>{{ $property->marque }}</td>
            <td>{{ $property->modele }}</td>
            <td>{{ $property->annee_fabrication }}</td>
            <td>{{ $property->transmission }}</td>
            <td>{{ number_format($property->prix, 0, ',', ' ') }}</td>
            <td>{{ $property->disponible }}</td>
            <td>
                <div class="d-flex gap-2 w-100 justify-content-end">
                    <a href="{{ route('admin.property.editform',$property)}}" class="btn btn-secondary">Editer</a>
                    <form action="{{ route('admin.property.destroy',$property)}}" method="post">
                        @csrf
                        @method('delete')
                        <button class="btn btn-danger">Supprimer</button>
                    </form>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
{{ $properties->links() }}

<a href="{{route('operation.index')}}">Voir toutes les opérations d'emprunt</a>

@endsection