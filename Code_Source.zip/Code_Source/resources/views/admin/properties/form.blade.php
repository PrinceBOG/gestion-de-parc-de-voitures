@extends('admin.admin')

@section('marque',$property->exists ? 'Editer un bien':'Créer une voiture')

@section('content')

<h1>@yield('marque')</h1>

<form class="vstack gap-2" action="{{ route($property->exists ? 'admin.property.edit': 'admin.property.store', $property) }}" method="post">

    @csrf
    @method($property->exists ? 'put':'post')

    <div class="row">
        @include('shared.input', ['class' => 'col','label'=>'Marque','name'=>'marque','value'=>$property->marque])
        <div class="col row">
            @include('shared.input', ['class' => 'col','name'=>'modele','value'=>$property->modele])
        </div>
    </div>
    <div class="row">
        @include('shared.input', ['class' => 'col','name'=>'annee_fabrication','value'=>$property->annee_fabrication])
        <div class="col row">
            @include('shared.input', ['class' => 'col','name'=>'capacite','value'=>$property->capacite_passagers])
        </div>
    </div>
    <div class="row">
        @include('shared.input', ['class' => 'col','name'=>'transmission','value'=>$property->transmission])
        <div class="col row">
            @include('shared.input', ['class' => 'col','name'=>'prix','value'=>$property->prix])
        </div>
    </div>

    <div class="form-group">
        <label for="image_url">Image de la voiture:</label>
        <input type="text" name="image_path" class="form-control" id="image_url" value="{{ old('image_url', $property->image_url) }}">
    </div>


    <div class="row">
        @include('shared.checkbox', ['name'=>'disponible','label'=>'Disponible', 'value'=>$property->disponible])
    </div>

    <button type="submit" class="btn btn-primary">
        @if($property->exists)
        Modifier
        @else
        Créer
        @endif
    </button>
</form>



@endsection