@extends('admin.admin')

@section('content')

<h1>@yield('marque')</h1>

<form class="vstack gap-2" action="" method="post">

    @csrf

    <div class="row">
        <label for="nom">Nom</label>
        <input type="text" name="nom" required>
    </div>

    <div class="row">
        <label for="prenom">Prénom</label>
        <input type="text" name="prenom" required>
    </div>

    <div class="row">
        <label for="marque">Marque</label>
        <input type="text" name="marque" required>
    </div>

    <div class="row">
        <label for="modele">Modèle</label>
        <input type="text" name="modele" required>
    </div>


    <div class="row">
        <label for="date">Date de restitution</label>
        <input type="text" name="date" required>
    </div>
    <h2></h2>
    <button type="submit" class="btn btn-primary">
        Restituer
    </button>

</form>

@endsection