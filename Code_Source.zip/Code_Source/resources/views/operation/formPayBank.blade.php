@extends('admin.admin')


@section('content')

<div class="mt-4">

    <form action="" method="post">
        @csrf
        <label for="carte">Numéro de compte</label>
        <input type="text" name="carte" required>
        <button type="submit">Soumettre</button>
    </form>
</div>

@endsection