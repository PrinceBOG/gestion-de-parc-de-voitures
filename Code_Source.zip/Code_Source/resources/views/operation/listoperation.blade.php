@extends('admin.admin')

@section('content')


<table class="table table-striped">
    <thead>
        <tr>
            <th>Nom</th>
            <th>Email</th>
            <th>Marque_Voiture</th>
            <th>Modele_Voiture</th>
            <th>Prix</th>
            <th>Date_Debut_Emprunt</th>
            <th>Date_Fin_Emprunt</th>
            <th>Date_Restitution</th>
        </tr>
    </thead>
    <tbody>
        @foreach($operations as $operation)
        <tr>
            <td>{{ $operation->nom_cli }}</td>
            <td>{{ $operation->email_cli }}</td>
            <td>{{ $operation->marque_voiture }}</td>
            <td>{{ $operation->modele_voiture }}</td>
            <td>{{ number_format($operation->prix, 0, ',', ' ') }}</td>
            <td>{{ $operation->date_debut_emprunt }}</td>
            <td>{{ $operation->date_fin_emprunt }}</td>
            <td>{{ $operation->date_restitution }}</td>
        </tr>
        @endforeach
    </tbody>
</table>


@endsection