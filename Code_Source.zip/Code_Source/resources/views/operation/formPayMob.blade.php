@extends('admin.admin')


@section('content')

<div class="mt-4">

    <form action="" method="post">
        @csrf
        <label for="num">Numéro de téléphone de la transaction</label>
        <input type="text" name="num" required>
        <button type="submit">Soumettre</button>
    </form>
</div>

@endsection