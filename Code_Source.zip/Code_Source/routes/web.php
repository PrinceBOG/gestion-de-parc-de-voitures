<?php

use App\Http\Controllers\Admin\PropertyController as AdminPropertyController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\CarsController as CarsController;
use App\Http\Controllers\OperationController;
use App\Http\Controllers\PaiementController;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

$idRegex = '[0-9]+';
$marqueRegex = '[0-9a-z\-]';

Route::get('/', [\App\Http\Controllers\HomeController::class, 'index']);

/*Route::prefix('admin')->name('admin.')->group(function () {
    Route::resource('property', AdminPropertyController::class)->except(['show']);
});*/



Route::get('/admin/property/create', [AdminPropertyController::class, 'create'])->name('admin.property.create')->middleware('auth');

//Route::post('/admin/property', [AdminPropertyController::class, 'store'])->name('admin.property.store');

Route::get('/admin/property', [AdminPropertyController::class, 'index'])->name('admin.property.index');

Route::post('/admin/property/edit', [AdminPropertyController::class, 'edit'])->name('admin.property.edit');

Route::get('/admin/property/edit', [AdminPropertyController::class, 'editform'])->name('admin.property.editform');

Route::get('/admin/property/update', [AdminPropertyController::class, 'update'])->name('admin.property.update');

Route::get('/admin/property/destroy', [AdminPropertyController::class, 'destroy'])->name('admin.property.destroy');

Route::post('/admin/property', [AdminPropertyController::class, 'store'])->name('admin.property.store');


//Route::get('/admin/property/justpage', [AdminPropertyController::class, 'justpage'])->name('admin.property.justpage');

Route::get('/voitures', [CarsController::class, 'index'])->name('cars.index');
/*Route::get('/voitures/{marque}->{property}', [\App\Http\Controllers\CarsController::class, 'show'])->name('cars.show')->where([
    'property' => $idRegex,
    'marque' => $marqueRegex
]);*/

Route::get('/voitures/show', [\App\Http\Controllers\CarsController::class, 'show'])->name('cars.show');

Route::get('/gallery/upload', 'GalleryController@showUploadForm')->name('gallery.upload.form');
Route::post('/gallery/upload', 'GalleryController@upload')->name('gallery.upload');

Route::get('/properties/create', 'PropertyController@create')->name('properties.create');
Route::post('/properties', 'PropertyController@store')->name('properties.store');

Route::get('/login', [\App\Http\Controllers\AuthController::class, 'login'])->name('login');
Route::post('/login', [\App\Http\Controllers\AuthController::class, 'dologin']);
Route::delete('/logout', [\App\Http\Controllers\AuthController::class, 'logout'])->name('logout');

Route::post('/biens/{property}/{contact}', [\App\Http\Controllers\CarsController::class, 'contact'])->name('cars.contact');

Route::get('/inscription', [\App\Http\Controllers\InscriptionController::class, 'inscrire'])->name('inscrire');
Route::post('/enregistrer', [\App\Http\Controllers\InscriptionController::class, 'enregistrer'])->name('enregistrer');
Route::post('/inscription', [\App\Http\Controllers\InscriptionController::class, 'valider']);
Route::get('/operation', [\App\Http\Controllers\OperationController::class, 'index'])->name('operation.index');

Route::get('/loginCli', [\App\Http\Controllers\AuthController::class, 'loginCli'])->name('loginCli');
Route::post('/loginCli', [\App\Http\Controllers\AuthController::class, 'dologinCli']);

Route::get('/MoMoPay', [\App\Http\Controllers\PaiementController::class, 'formPayMob'])->name('formPayMob');
Route::get('/BankPay', [\App\Http\Controllers\PaiementController::class, 'formPayBank'])->name('formPayBank');

Route::get('/Restitution', [\App\Http\Controllers\PaiementController::class, 'restitution'])->name('restitution');

Route::get('/loginRest', [\App\Http\Controllers\AuthController::class, 'loginRest'])->name('loginRest');
Route::post('/loginRest', [\App\Http\Controllers\AuthController::class, 'dologinRest']);
